MK64 Portable 1.7-test

An unofficial fan port for the PSP. It contains no game data: it needs a ROM
of Mario Kart 64 (USA) that you own. Not affiliated with or endorsed by Nintendo.

1. Copy the MK64Portable folder to ms0:/PSP/GAME/ on your Memory Stick.
2. Put your Mario Kart 64 (USA) ROM (.z64, .n64 or .v64) in that folder, next to EBOOT.PBP.
3. Start MK64 Portable from the XMB. The first start reads the ROM and builds the game
   data (about 13 MB) into a data/ folder; later starts skip this. Your save is kept there too.

Single-player races run at 60 fps; heavy stretches drop to 30 fps for a moment.
Ad hoc multiplayer: WLAN switch on, pick 2P/3P/4P GAME on every PSP, then HOST or JOIN.
Every PSP needs this same version of MK64 Portable.

Controls: steer with the analog nub or the D-pad; Cross = A, Square = B, Circle or L = Z,
R = hop, Triangle = C-up, Start = pause. Hold Select for 3 seconds to show the FPS counter.
